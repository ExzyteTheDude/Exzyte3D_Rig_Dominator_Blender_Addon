
bl_info = {
    "name": "Exzyte3D RIG DOMINATOR",
    "author": "Exzyte3D & ChatGPT",
    "version": (2, 2),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Exzyte3D",
    "description": "Brands all rig bones with a custom prefix and restores original names",
    "category": "Rigging",
}

import bpy
import ast

class EXZ_PT_MainPanel(bpy.types.Panel):
    bl_label = "Exzyte3D RIG DOMINATOR 💀"
    bl_idname = "EXZ_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Exzyte3D'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "exz_prefix")
        layout.operator("exz.brand_all_bones", icon="BONE_DATA")
        layout.operator("exz.restore_bone_names", icon="LOOP_BACK")

class EXZ_OT_BrandBones(bpy.types.Operator):
    bl_idname = "exz.brand_all_bones"
    bl_label = "🔥 Brand All Rigs"
    bl_description = "Rename all bones & vertex groups with your prefix"

    def execute(self, context):
        prefix = context.scene.exz_prefix

        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')

                original_names = {}
                for bone in obj.data.edit_bones:
                    clean_name = bone.name.split(":")[-1]
                    original_names[bone.name] = clean_name
                    bone.name = f"{prefix}{clean_name}"

                obj["exz_original_names"] = str(original_names)
                bpy.ops.object.mode_set(mode='OBJECT')

                for mesh in bpy.data.objects:
                    if mesh.type == 'MESH' and mesh.parent == obj:
                        for vg in mesh.vertex_groups:
                            vg.name = f"{prefix}{vg.name.split(':')[-1]}"

        self.report({'INFO'}, f"💀 Branded with prefix: {prefix}")
        return {'FINISHED'}

class EXZ_OT_RestoreBones(bpy.types.Operator):
    bl_idname = "exz.restore_bone_names"
    bl_label = "↩️ Restore Original Names"
    bl_description = "Revert bones to their original names"

    def execute(self, context):
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE' and "exz_original_names" in obj.keys():
                original = ast.literal_eval(obj["exz_original_names"])
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')

                for bone in obj.data.edit_bones:
                    for old_name, clean_name in original.items():
                        if bone.name == f"{context.scene.exz_prefix}{clean_name}":
                            bone.name = old_name

                bpy.ops.object.mode_set(mode='OBJECT')
                self.report({'INFO'}, f"✔️ Restored: {obj.name}")
            else:
                self.report({'WARNING'}, f"⚠️ No original names found for {obj.name}")
        return {'FINISHED'}

classes = [EXZ_PT_MainPanel, EXZ_OT_BrandBones, EXZ_OT_RestoreBones]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.exz_prefix = bpy.props.StringProperty(
        name="Prefix",
        default="Exzyte3D(The Dude):",
        description="Prefix for branding bones"
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.exz_prefix

if __name__ == "__main__":
    register()
